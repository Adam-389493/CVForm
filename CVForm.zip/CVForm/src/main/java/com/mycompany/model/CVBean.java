/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author user
 */
public class CVBean implements Serializable {

    private static final long serialVersionUID = 1L;

    // ---- Personal Info ----
    private String fullName;
    private String professionalTitle;
    private String email;
    private String phone;
    private String profileUrl;      // LinkedIn / GitHub
    private String profileSummary;

    // ---- Education ----
    private String degree;
    private String institution;
    private String graduationYear;
    private String major;

    // ---- Experience ----
    private String jobTitle;
    private String company;
    private String duration;
    private String responsibilities;

    // ---- Skills ----
    private String technicalSkills; // comma-separated
    private String softSkills;      // comma-separated

    // ---- Validation result ----
    private List<String> errors = new ArrayList<String>();

    /** Zero-argument constructor (required for a JavaBean). */
    public CVBean() {
    }

    // =====================================================
    // Validation
    // =====================================================

    /**
     * Validates mandatory fields: Name, Email, Degree and at least one Skill.
     * Also checks email format and (if supplied) graduation year format.
     *
     * @return true if all rules pass; otherwise false and getErrors() is filled.
     */
    public boolean validate() {
        errors.clear();

        if (isBlank(fullName)) {
            errors.add("Full Name is required.");
        }

        if (isBlank(email)) {
            errors.add("Email is required.");
        } else if (!email.trim().matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
            errors.add("Email format is invalid (e.g. name@example.com).");
        }

        if (isBlank(degree)) {
            errors.add("Highest Degree is required.");
        }

        if (getTechnicalSkillsList().isEmpty() && getSoftSkillsList().isEmpty()) {
            errors.add("At least one skill (technical or soft) is required.");
        }

        if (!isBlank(graduationYear) && !graduationYear.trim().matches("^(19|20)\\d{2}$")) {
            errors.add("Year of Graduation must be a valid 4-digit year (e.g. 2025).");
        }

        if (!isBlank(phone) && !phone.trim().matches("^[0-9+()\\-\\s]{7,20}$")) {
            errors.add("Phone Number is malformed.");
        }

        return errors.isEmpty();
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private List<String> splitCsv(String csv) {
        List<String> list = new ArrayList<String>();
        if (csv != null) {
            for (String part : csv.split(",")) {
                if (!part.trim().isEmpty()) {
                    list.add(part.trim());
                }
            }
        }
        return list;
    }

    /** Helper so the JSP can iterate skills without scriptlets. */
    public List<String> getTechnicalSkillsList() {
        return splitCsv(technicalSkills);
    }

    public List<String> getSoftSkillsList() {
        return splitCsv(softSkills);
    }

    /** Helper so the JSP can render responsibilities as bullet points (one per line). */
    public List<String> getResponsibilitiesList() {
        List<String> list = new ArrayList<String>();
        if (responsibilities != null) {
            for (String line : responsibilities.split("\\r?\\n")) {
                if (!line.trim().isEmpty()) {
                    list.add(line.trim());
                }
            }
        }
        return list;
    }

    // =====================================================
    // Getters & Setters
    // =====================================================

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getProfessionalTitle() { return professionalTitle; }
    public void setProfessionalTitle(String professionalTitle) { this.professionalTitle = professionalTitle; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getProfileUrl() { return profileUrl; }
    public void setProfileUrl(String profileUrl) { this.profileUrl = profileUrl; }

    public String getProfileSummary() { return profileSummary; }
    public void setProfileSummary(String profileSummary) { this.profileSummary = profileSummary; }

    public String getDegree() { return degree; }
    public void setDegree(String degree) { this.degree = degree; }

    public String getInstitution() { return institution; }
    public void setInstitution(String institution) { this.institution = institution; }

    public String getGraduationYear() { return graduationYear; }
    public void setGraduationYear(String graduationYear) { this.graduationYear = graduationYear; }

    public String getMajor() { return major; }
    public void setMajor(String major) { this.major = major; }

    public String getJobTitle() { return jobTitle; }
    public void setJobTitle(String jobTitle) { this.jobTitle = jobTitle; }

    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }

    public String getDuration() { return duration; }
    public void setDuration(String duration) { this.duration = duration; }

    public String getResponsibilities() { return responsibilities; }
    public void setResponsibilities(String responsibilities) { this.responsibilities = responsibilities; }

    public String getTechnicalSkills() { return technicalSkills; }
    public void setTechnicalSkills(String technicalSkills) { this.technicalSkills = technicalSkills; }

    public String getSoftSkills() { return softSkills; }
    public void setSoftSkills(String softSkills) { this.softSkills = softSkills; }

    public List<String> getErrors() { return errors; }
}

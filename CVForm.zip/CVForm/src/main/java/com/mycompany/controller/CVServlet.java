/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.controller;
import com.mycompany.model.CVBean;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


/**
 *
 * @author user
 */
public class CVServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("sample".equals(action)) {
            // Build a sample CV using setters
            CVBean sample = new CVBean();
            sample.setFullName("Aisyah Binti Rahman");
            sample.setProfessionalTitle("Junior Software Engineer");
            sample.setEmail("aisyah.rahman@example.com");
            sample.setPhone("+60 12-345 6789");
            sample.setProfileUrl("https://github.com/aisyah-rahman");
            sample.setProfileSummary("Motivated computer science graduate with hands-on experience "
                    + "in Java EE and web application development. Passionate about clean "
                    + "architecture, MVC design and building reliable, user-friendly software.");

            sample.setDegree("Bachelor of Computer Science (Hons.)");
            sample.setInstitution("Universiti Teknologi MARA (UiTM)");
            sample.setGraduationYear("2025");
            sample.setMajor("Software Engineering");

            sample.setJobTitle("Software Engineer Intern");
            sample.setCompany("TechNova Solutions Sdn. Bhd.");
            sample.setDuration("Jun 2024 - Dec 2024");
            sample.setResponsibilities(
                    "Developed RESTful services using Java Servlets and JSP.\n"
                  + "Designed MySQL schemas and optimised queries, reducing report time by 30%.\n"
                  + "Collaborated in an Agile team and participated in weekly code reviews.");

            sample.setTechnicalSkills("Java, JSP/Servlets, SQL, HTML/CSS, JavaScript, Git");
            sample.setSoftSkills("Communication, Teamwork, Problem Solving, Time Management");

            request.setAttribute("cvData", sample);
            request.setAttribute("isSample", Boolean.TRUE);
            forward(request, response, "/cvView.jsp");
        } else {
            // No/unknown action: send user to the form
            response.sendRedirect(request.getContextPath() + "/cvForm.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        // 1. Extract parameters and populate the model
        CVBean cv = new CVBean();
        cv.setFullName(request.getParameter("fullName"));
        cv.setProfessionalTitle(request.getParameter("professionalTitle"));
        cv.setEmail(request.getParameter("email"));
        cv.setPhone(request.getParameter("phone"));
        cv.setProfileUrl(request.getParameter("profileUrl"));
        cv.setProfileSummary(request.getParameter("profileSummary"));

        cv.setDegree(request.getParameter("degree"));
        cv.setInstitution(request.getParameter("institution"));
        cv.setGraduationYear(request.getParameter("graduationYear"));
        cv.setMajor(request.getParameter("major"));

        cv.setJobTitle(request.getParameter("jobTitle"));
        cv.setCompany(request.getParameter("company"));
        cv.setDuration(request.getParameter("duration"));
        cv.setResponsibilities(request.getParameter("responsibilities"));

        cv.setTechnicalSkills(request.getParameter("technicalSkills"));
        cv.setSoftSkills(request.getParameter("softSkills"));

        // 2. Validate via the bean
        if (cv.validate()) {
            request.setAttribute("cvData", cv);
            forward(request, response, "/cvView.jsp");
        } else {
            request.setAttribute("errorMessage", "Please correct the following problems and resubmit.");
            request.setAttribute("errors", cv.getErrors());
            request.setAttribute("cvData", cv); // allows form to be re-filled
            forward(request, response, "/cvError.jsp");
        }
    }

    private void forward(HttpServletRequest request, HttpServletResponse response, String path)
            throws ServletException, IOException {
        RequestDispatcher rd = request.getRequestDispatcher(path);
        rd.forward(request, response);
    }
}

<%-- 
    Document   : cvForm
    Created on : 21 Nov 2026, 6:55:09 pm
    Author     : user
--%>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CV Builder - Enter Details</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body class="form-page">
<div class="container">
    <header class="page-header">
        <h1>Dynamic Online CV Builder</h1>
        <p>Fill in your details to generate a professional CV, or preview a sample.</p>
        <a class="btn btn-secondary" href="${pageContext.request.contextPath}/CVServlet?action=sample">Preview Sample CV</a>
    </header>

    <form action="${pageContext.request.contextPath}/CVServlet" method="post" class="cv-form">

        <fieldset>
            <legend>Personal Information</legend>
            <div class="grid">
                <label>Full Name *
                    <input type="text" name="fullName" value="<c:out value='${cvData.fullName}'/>" required>
                </label>
                <label>Professional Title
                    <input type="text" name="professionalTitle" value="<c:out value='${cvData.professionalTitle}'/>">
                </label>
                <label>Email *
                    <input type="email" name="email" value="<c:out value='${cvData.email}'/>" required>
                </label>
                <label>Phone Number
                    <input type="tel" name="phone" value="<c:out value='${cvData.phone}'/>">
                </label>
                <label class="full">LinkedIn / GitHub URL
                    <input type="url" name="profileUrl" value="<c:out value='${cvData.profileUrl}'/>">
                </label>
                <label class="full">Profile Summary
                    <textarea name="profileSummary" rows="4"><c:out value='${cvData.profileSummary}'/></textarea>
                </label>
            </div>
        </fieldset>

        <fieldset>
            <legend>Education</legend>
            <div class="grid">
                <label>Highest Degree *
                    <input type="text" name="degree" value="<c:out value='${cvData.degree}'/>" required>
                </label>
                <label>Institution Name
                    <input type="text" name="institution" value="<c:out value='${cvData.institution}'/>">
                </label>
                <label>Year of Graduation
                    <input type="text" name="graduationYear" maxlength="4" placeholder="e.g. 2025" value="<c:out value='${cvData.graduationYear}'/>">
                </label>
                <label>Major / Field
                    <input type="text" name="major" value="<c:out value='${cvData.major}'/>">
                </label>
            </div>
        </fieldset>

        <fieldset>
            <legend>Experience</legend>
            <div class="grid">
                <label>Most Recent Job Title
                    <input type="text" name="jobTitle" value="<c:out value='${cvData.jobTitle}'/>">
                </label>
                <label>Company Name
                    <input type="text" name="company" value="<c:out value='${cvData.company}'/>">
                </label>
                <label class="full">Duration
                    <input type="text" name="duration" placeholder="e.g. Jun 2024 - Dec 2024" value="<c:out value='${cvData.duration}'/>">
                </label>
                <label class="full">Key Responsibilities / Achievements (one per line)
                    <textarea name="responsibilities" rows="5"><c:out value='${cvData.responsibilities}'/></textarea>
                </label>
            </div>
        </fieldset>

        <fieldset>
            <legend>Skills</legend>
            <div class="grid">
                <label class="full">Technical Skills * (comma-separated)
                    <input type="text" name="technicalSkills" placeholder="Java, SQL, HTML" value="<c:out value='${cvData.technicalSkills}'/>">
                </label>
                <label class="full">Soft Skills (comma-separated)
                    <input type="text" name="softSkills" placeholder="Teamwork, Communication" value="<c:out value='${cvData.softSkills}'/>">
                </label>
            </div>
        </fieldset>

        <div class="actions">
            <button type="submit" class="btn btn-primary">Generate CV</button>
            <button type="reset" class="btn btn-secondary">Clear</button>
        </div>
    </form>
</div>
</body>
</html>


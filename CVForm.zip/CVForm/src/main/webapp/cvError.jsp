<%-- 
    Document   : cvError
    Created on : 21 Nov 2026, 6:54:40 pm
    Author     : user
--%>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CV Builder - Validation Error</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body class="form-page">
<div class="container">
    <div class="error-box">
        <h1>Unable to generate CV</h1>
        <p><c:out value="${errorMessage}"/></p>
        <ul>
            <c:forEach var="err" items="${errors}">
                <li><c:out value="${err}"/></li>
            </c:forEach>
        </ul>
        <!-- Request-scope data is kept, so the form is re-filled when we forward back to it -->
        <form action="${pageContext.request.contextPath}/cvForm.jsp" method="get">
            <a class="btn btn-primary" href="javascript:history.back()">&larr; Go back and correct</a>
            <a class="btn btn-secondary" href="${pageContext.request.contextPath}/cvForm.jsp">Start over</a>
        </form>
    </div>
</div>
</body>
</html>


<%-- 
    Document   : cvView
    Created on : 21 Nov 2026, 6:56:11 pm
    Author     : user
--%>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><c:out value="${cvData.fullName}"/> - Curriculum Vitae</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body class="view-page">

<div class="toolbar no-print">
    <a class="btn btn-secondary" href="${pageContext.request.contextPath}/cvForm.jsp">&larr; Back to Form</a>
    <c:if test="${isSample}"><span class="badge">Sample Data</span></c:if>
    <button class="btn btn-primary" onclick="window.print()">Print / Save as PDF</button>
</div>

<main class="cv">
    <header class="cv-header">
        <h1><c:out value="${cvData.fullName}"/></h1>
        <c:if test="${not empty cvData.professionalTitle}">
            <h2><c:out value="${cvData.professionalTitle}"/></h2>
        </c:if>
        <ul class="contact">
            <li><c:out value="${cvData.email}"/></li>
            <c:if test="${not empty cvData.phone}"><li><c:out value="${cvData.phone}"/></li></c:if>
            <c:if test="${not empty cvData.profileUrl}"><li><c:out value="${cvData.profileUrl}"/></li></c:if>
        </ul>
    </header>

    <c:if test="${not empty cvData.profileSummary}">
        <section>
            <h3>Profile</h3>
            <p><c:out value="${cvData.profileSummary}"/></p>
        </section>
    </c:if>

    <section>
        <h3>Education</h3>
        <div class="entry">
            <div class="entry-head">
                <strong><c:out value="${cvData.degree}"/></strong>
                <c:if test="${not empty cvData.graduationYear}">
                    <span class="date"><c:out value="${cvData.graduationYear}"/></span>
                </c:if>
            </div>
            <c:if test="${not empty cvData.institution}"><div><c:out value="${cvData.institution}"/></div></c:if>
            <c:if test="${not empty cvData.major}"><div class="muted">Major: <c:out value="${cvData.major}"/></div></c:if>
        </div>
    </section>

    <c:if test="${not empty cvData.jobTitle or not empty cvData.company}">
        <section>
            <h3>Experience</h3>
            <div class="entry">
                <div class="entry-head">
                    <strong><c:out value="${cvData.jobTitle}"/></strong>
                    <c:if test="${not empty cvData.duration}">
                        <span class="date"><c:out value="${cvData.duration}"/></span>
                    </c:if>
                </div>
                <div><c:out value="${cvData.company}"/></div>
                <ul>
                    <c:forEach var="item" items="${cvData.responsibilitiesList}">
                        <li><c:out value="${item}"/></li>
                    </c:forEach>
                </ul>
            </div>
        </section>
    </c:if>

    <section>
        <h3>Skills</h3>
        <c:if test="${not empty cvData.technicalSkillsList}">
            <div class="skills-row"><span class="skills-label">Technical</span>
                <c:forEach var="s" items="${cvData.technicalSkillsList}">
                    <span class="chip"><c:out value="${s}"/></span>
                </c:forEach>
            </div>
        </c:if>
        <c:if test="${not empty cvData.softSkillsList}">
            <div class="skills-row"><span class="skills-label">Soft</span>
                <c:forEach var="s" items="${cvData.softSkillsList}">
                    <span class="chip"><c:out value="${s}"/></span>
                </c:forEach>
            </div>
        </c:if>
    </section>
</main>

</body>
</html>

